#ifndef SIMDJSON_HASWELL_ONDEMAND_H
#define SIMDJSON_HASWELL_ONDEMAND_H

#include "simdjson/haswell/begin.h"
#include "simdjson/generic/ondemand/amalgamated.h"
#include "simdjson/haswell/end.h"

#endif // SIMDJSON_HASWELL_ONDEMAND_H
