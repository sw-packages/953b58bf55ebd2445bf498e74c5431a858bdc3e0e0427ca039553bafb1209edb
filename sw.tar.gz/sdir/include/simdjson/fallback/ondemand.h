#ifndef SIMDJSON_FALLBACK_ONDEMAND_H
#define SIMDJSON_FALLBACK_ONDEMAND_H

#include "simdjson/fallback/begin.h"
#include "simdjson/generic/ondemand/amalgamated.h"
#include "simdjson/fallback/end.h"

#endif // SIMDJSON_FALLBACK_ONDEMAND_H
